(function () {

  "use strict";

  document.documentElement.classList.add("js");

  /* =========================================================

     EDIT YOUR PROJECTS HERE

     ========================================================= */

  var PROJECTS = []; // Add your real projects here; sample projects were removed.

  var $ = function (sel, root) { return (root || document).querySelector(sel); };

  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- Footer year ---------- */

  var yearEl = $("#year");

  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ---------- Theme toggle ---------- */

  var root = document.documentElement;

  var themeBtn = $("#themeToggle");

  function applyTheme(theme) {

    root.setAttribute("data-theme", theme);

    if (themeBtn) {

      themeBtn.setAttribute("aria-label", theme === "dark" ? "Switch to light theme" : "Switch to dark theme");

    }

    var meta = $('meta[name="theme-color"]');

    if (meta) meta.setAttribute("content", theme === "dark" ? "#0f172a" : "#f8fafc");

  }

  applyTheme(root.getAttribute("data-theme") || "dark");

  if (themeBtn) {

    themeBtn.addEventListener("click", function () {

      var next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";

      applyTheme(next);

      try { localStorage.setItem("theme", next); } catch (e) { /* storage unavailable */ }

    });

  }

  /* ---------- Mobile menu ---------- */

  var menuBtn = $("#menuToggle");

  var nav = $("#nav");

  function setMenu(open) {

    nav.classList.toggle("open", open);

    menuBtn.setAttribute("aria-expanded", String(open));

    menuBtn.setAttribute("aria-label", open ? "Close menu" : "Open menu");

  }

  menuBtn.addEventListener("click", function () {

    setMenu(menuBtn.getAttribute("aria-expanded") !== "true");

  });

  $$(".nav-link").forEach(function (link) {

    link.addEventListener("click", function () { setMenu(false); });

  });

  document.addEventListener("click", function (e) {

    if (nav.classList.contains("open") && !nav.contains(e.target) && !menuBtn.contains(e.target)) {

      setMenu(false);

    }

  });

  window.addEventListener("resize", function () {

    if (window.innerWidth >= 900) setMenu(false);

  });

  /* ---------- Header shadow + scroll spy ---------- */

  var header = $(".site-header");

  function onScroll() {

    header.classList.toggle("scrolled", window.scrollY > 10);

  }

  window.addEventListener("scroll", onScroll, { passive: true });

  onScroll();

  var sections = $$("main section[id]");

  var links = $$(".nav-link");

  function setActive(id) {

    links.forEach(function (l) {

      var active = l.getAttribute("href") === "#" + id;

      l.classList.toggle("active", active);

      if (active) l.setAttribute("aria-current", "page"); else l.removeAttribute("aria-current");

    });

  }

  if ("IntersectionObserver" in window) {

    var spy = new IntersectionObserver(function (entries) {

      entries.forEach(function (entry) {

        if (entry.isIntersecting) setActive(entry.target.id);

      });

    }, { rootMargin: "-45% 0px -50% 0px", threshold: 0 });

    sections.forEach(function (s) { spy.observe(s); });

  }

  /* ---------- Typing effect ---------- */

  var typedEl = $("#typed");

  var words = ["web apps", "REST APIs", "clean UIs", "real products"];

  if (typedEl && !reduceMotion) {

    var w = 0, c = 0, deleting = false;

    (function tick() {

      var word = words[w];

      typedEl.textContent = word.substring(0, c);

      var delay = deleting ? 45 : 95;

      if (!deleting && c === word.length) { deleting = true; delay = 1400; }

      else if (deleting && c === 0) { deleting = false; w = (w + 1) % words.length; delay = 350; }

      c += deleting ? -1 : 1;

      setTimeout(tick, delay);

    })();

  }

  /* ---------- Reveal on scroll + counters + skill bars ---------- */

  function countUp(el) {

    var target = parseInt(el.getAttribute("data-count"), 10) || 0;

    if (reduceMotion) { el.textContent = target; return; }

    var start = null, dur = 1100;

    function step(ts) {

      if (!start) start = ts;

      var p = Math.min((ts - start) / dur, 1);

      el.textContent = Math.round(target * p);

      if (p < 1) requestAnimationFrame(step);

    }

    requestAnimationFrame(step);

  }

  function reveal(el) {

    el.classList.add("in-view");

    $$("[data-count]", el).forEach(countUp);

  }

  function observeReveals(scope) {

    var items = $$(".reveal", scope);

    if (!("IntersectionObserver" in window)) { items.forEach(reveal); return; }

    var io = new IntersectionObserver(function (entries, obs) {

      entries.forEach(function (entry) {

        if (entry.isIntersecting) { reveal(entry.target); obs.unobserve(entry.target); }

      });

    }, { threshold: 0.12 });

    items.forEach(function (el) { io.observe(el); });

  }

  observeReveals(document);

  /* ---------- Projects: render, filter ---------- */

  var grid = $("#projectsGrid");

  function el(tag, cls, text) {

    var n = document.createElement(tag);

    if (cls) n.className = cls;

    if (text !== undefined) n.textContent = text;

    return n;

  }

  PROJECTS.forEach(function (p) {

    var card = el("button", "project-card reveal");

    card.type = "button";

    card.setAttribute("data-id", p.id);

    card.setAttribute("data-category", p.category);

    card.setAttribute("aria-haspopup", "dialog");

    card.setAttribute("aria-label", "View details for " + p.title);

    var thumb = el("div", "thumb " + p.gradient, p.icon);

    thumb.setAttribute("aria-hidden", "true");

    var body = el("div", "project-body");

    body.appendChild(el("h3", "", p.title));

    body.appendChild(el("p", "", p.summary));

    var chips = el("ul", "chips");

    p.tech.slice(0, 3).forEach(function (t) { chips.appendChild(el("li", "", t)); });

    body.appendChild(chips);

    body.appendChild(el("span", "more", "View details \u2192"));

    card.appendChild(thumb);

    card.appendChild(body);

    grid.appendChild(card);

  });

  observeReveals(grid);

  $$(".filter").forEach(function (btn) {

    btn.addEventListener("click", function () {

      var f = btn.getAttribute("data-filter");

      $$(".filter").forEach(function (b) { b.classList.toggle("active", b === btn); });

      $$(".project-card").forEach(function (card) {

        var show = f === "all" || card.getAttribute("data-category") === f;

        card.hidden = !show;

        if (show) card.classList.add("in-view");

      });

    });

  });

  /* ---------- Project modal ---------- */

  var modal = $("#projectModal");

  var dialog = $(".modal-dialog", modal);

  var lastFocused = null;

  function openModal(id) {

    var p = PROJECTS.filter(function (x) { return x.id === id; })[0];

    if (!p) return;

    lastFocused = document.activeElement;

    var hero = $("#modalHero");

    hero.className = "modal-hero " + p.gradient;

    hero.textContent = p.icon;

    $("#modalTitle").textContent = p.title;

    $("#modalDesc").textContent = p.description;

    var feats = $("#modalFeatures");

    feats.innerHTML = "";

    p.features.forEach(function (f) { feats.appendChild(el("li", "", f)); });

    var tech = $("#modalTech");

    tech.innerHTML = "";

    p.tech.forEach(function (t) { tech.appendChild(el("li", "", t)); });

    $("#modalLive").href = p.live;

    $("#modalCode").href = p.code;

    modal.hidden = false;

    document.body.classList.add("no-scroll");

    dialog.scrollTop = 0;

    dialog.focus();

  }

  function closeModal() {

    if (modal.hidden) return;

    modal.hidden = true;

    document.body.classList.remove("no-scroll");

    if (lastFocused && lastFocused.focus) lastFocused.focus();

  }

  grid.addEventListener("click", function (e) {

    var card = e.target.closest(".project-card");

    if (card) openModal(card.getAttribute("data-id"));

  });

  modal.addEventListener("click", function (e) {

    if (e.target.hasAttribute("data-close")) closeModal();

  });

  document.addEventListener("keydown", function (e) {

    if (modal.hidden) return;

    if (e.key === "Escape") { closeModal(); return; }

    if (e.key === "Tab") {

      var focusable = $$("a[href], button:not([disabled])", dialog).filter(function (n) { return n.offsetParent !== null; });

      if (!focusable.length) return;

      var first = focusable[0], last = focusable[focusable.length - 1];

      if (e.shiftKey && (document.activeElement === first || document.activeElement === dialog)) {

        e.preventDefault(); last.focus();

      } else if (!e.shiftKey && document.activeElement === last) {

        e.preventDefault(); first.focus();

      }

    }

  });

  /* ---------- Contact form (validates, then opens the visitor's mail app) ---------- */

  var CONTACT_EMAIL = "ateeq.foundationa@gmail.com";

  var form = $("#contactForm");

  var status = $("#formStatus");

  function setError(input, msg) {

    var field = input.closest(".field");

    field.classList.toggle("invalid", !!msg);

    $(".error", field).textContent = msg || "";

    input.setAttribute("aria-invalid", msg ? "true" : "false");

  }

  function validate() {

    var ok = true;

    var name = form.elements.name, email = form.elements.email, message = form.elements.message;

    if (name.value.trim().length < 2) { setError(name, "Please enter your name."); ok = false; } else setError(name, "");

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) { setError(email, "Please enter a valid email."); ok = false; } else setError(email, "");

    if (message.value.trim().length < 10) { setError(message, "Message should be at least 10 characters."); ok = false; } else setError(message, "");

    return ok;

  }

  form.addEventListener("submit", function (e) {

    e.preventDefault();

    status.textContent = "";

    if (!validate()) return;

    var subject = encodeURIComponent("Portfolio contact from " + form.elements.name.value.trim());

    var body = encodeURIComponent(

      form.elements.message.value.trim() + "\n\n\u2014 " + form.elements.name.value.trim() + " (" + form.elements.email.value.trim() + ")"

    );

    window.location.href = "mailto:" + CONTACT_EMAIL + "?subject=" + subject + "&body=" + body;

    status.textContent = "Thanks! Your email app should open with the message ready to send.";

    form.reset();

  });

  ["name", "email", "message"].forEach(function (n) {

    form.elements[n].addEventListener("input", function () {

      if (form.elements[n].closest(".field").classList.contains("invalid")) validate();

    });

  });

})();
