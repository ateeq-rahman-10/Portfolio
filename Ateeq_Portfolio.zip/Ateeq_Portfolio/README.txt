ATEEQ UR RAHMAN — PORTFOLIO WEBSITE

FILES
- index.html: website structure/content
- style.css: visual design and responsive layout
- script.js: theme toggle, mobile menu, animations, projects, and contact form

HOW TO RUN
1. Extract this folder.
2. Open the folder in VS Code.
3. Open index.html in your browser, or use the Live Server extension.
4. Update your GitHub and LinkedIn URLs in index.html (search for YOUR_USERNAME).
5. Add your real projects in script.js in the PROJECTS array.

NOTE
The project list is intentionally empty so the site does not show fictional projects.
The contact form prepares an email using the visitor's email app; it does not send email directly.
